package reiz;

import java.util.Scanner;

public class Clock {

    private static final int DEGREES_PER_HOUR = 30;
    private static final int MINUTES_PER_HOUR = 60;

    public static void calculateLesserAngle() {
    	Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the hour (1-12): ");
        int hour = scanner.nextInt();
        while (hour < 1 || hour > 12) {
            System.out.println("Invalid hour! Please enter a value between 1 and 12.");
            hour = scanner.nextInt();
        }

        System.out.print("Enter the minutes (0-59): ");
        int minutes = scanner.nextInt();
        while (minutes < 0 || minutes > 59) {
            System.out.println("Invalid minutes! Please enter a value between 0 and 59.");
            minutes = scanner.nextInt();
        }

        double hourAngle = hour* 30;
        double minuteAngle = (11*minutes)/2.0; 

        double angle = Math.abs(hourAngle - minuteAngle);
        angle = Math.min(angle, 360 - angle); // Consider the smaller angle between the two hands

        System.out.println("The lesser angle between the hour and minute hands is: " + angle + " degrees");
    }


    public static void main(String[] args) {
        calculateLesserAngle();
    }
}







